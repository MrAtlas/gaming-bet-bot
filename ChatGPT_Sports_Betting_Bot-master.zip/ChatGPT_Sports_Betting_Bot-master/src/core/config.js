// Replace with your own firebase config!
export const FIREBASE_CONFIG = {
 apiKey: "AIzaSyB55OOWTWROQumWL84P79txhwD2HspvSZs",
  authDomain: "gpt-wager.firebaseapp.com",
  projectId: "gpt-wager",
  storageBucket: "gpt-wager.appspot.com",
  messagingSenderId: "380002747460",
  appId: "1:380002747460:web:7f3191826cc2c84eaf6811",
  measurementId: "G-YG2GY8D0FB"
}

// Replace with your own IDs! follow the guides here:
// https://docs.expo.io/versions/latest/sdk/google/#using-it-inside-of-the-expo-app
export const ANDROID_GOOGLE_CLIENT_ID =
  '878215484396-4pbcf3tghqe9sa0pvq3fifb5etnn4q6s.apps.googleusercontent.com'
export const IOS_GOOGLE_CLIENT_ID =
  '878215484396-5hiqfjetgvbdck03l0jepdgku6u64erm.apps.googleusercontent.com'

// Replace with your own facebook app ID.
// You can find more information how to generate one here:
// https://docs.expo.io/versions/latest/sdk/facebook/#registering-your-app-with-facebook
export const FACEBOOK_APP_ID = '820370405209413'
